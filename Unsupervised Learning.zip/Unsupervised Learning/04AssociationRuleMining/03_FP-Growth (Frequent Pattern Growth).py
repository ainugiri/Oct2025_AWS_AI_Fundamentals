import pandas as pd
from mlxtend.frequent_patterns import fpgrowth, association_rules

import matplotlib.pyplot as plt

# Sample dataset
data = {'Milk': [1, 0, 1, 1, 0, 1],
    'Bread': [1, 1, 0, 1, 1, 1],
    'Butter': [0, 1, 1, 1, 0, 1],
    'Beer': [0, 0, 0, 1, 1, 0]}

df = pd.DataFrame(data)

# Train the model using FP-Growth
frequent_itemsets = fpgrowth(df, min_support=0.5, use_colnames=True)
rules = association_rules(frequent_itemsets, metric="confidence", min_threshold=0.7)

# Show the accuracy factors
print("Frequent Itemsets:")
print(frequent_itemsets)
print("\nAssociation Rules:")
print(rules)

# Visualize the data
plt.figure(figsize=(10, 6))
plt.bar(frequent_itemsets['itemsets'].astype(str), frequent_itemsets['support'], color='skyblue')
plt.xlabel('Itemsets')
plt.ylabel('Support')
plt.title('Frequent Itemsets Support')
plt.xticks(rotation=45)
plt.show()

# Predict for user input
user_input = {'Milk': 1, 'Bread': 1, 'Butter': 0, 'Beer': 0}
user_df = pd.DataFrame([user_input])

# Find matching rules
matching_rules = rules[rules['antecedents'].apply(lambda x: x.issubset(user_df.columns[user_df.iloc[0] == 1]))]

print("\nMatching Rules for User Input:")
print(matching_rules)

# Visualize the matching rules
plt.figure(figsize=(10, 6))
plt.bar(matching_rules['consequents'].astype(str), matching_rules['confidence'], color='lightgreen')
plt.xlabel('Consequents')
plt.ylabel('Confidence')
plt.title('Matching Rules Confidence')
plt.xticks(rotation=45)
plt.show()