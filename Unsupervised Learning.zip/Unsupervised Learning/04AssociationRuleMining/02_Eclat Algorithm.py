import pandas as pd
from itertools import combinations
from collections import defaultdict

import matplotlib.pyplot as plt

# Load dataset
data = {
    'TID': [1, 2, 3, 4, 5],
    'Items': [
        ['Milk', 'Bread', 'Butter'],
        ['Bread', 'Butter'],
        ['Milk', 'Bread', 'Butter', 'Eggs'],
        ['Milk', 'Eggs'],
        ['Bread', 'Butter', 'Eggs']
    ]
}

df = pd.DataFrame(data)

# Eclat Algorithm
def eclat(data, min_support=2):
    itemsets = defaultdict(int)
    for transaction in data:
        for item in transaction:
            itemsets[frozenset([item])] += 1

    def recursive_eclat(prefix, items, min_support):
        while items:
            item = items.pop()
            new_prefix = prefix | item
            support = sum(1 for transaction in data if new_prefix.issubset(transaction))
            if support >= min_support:
                yield (new_prefix, support)
                remaining_items = [other_item for other_item in items if other_item > item]
                yield from recursive_eclat(new_prefix, remaining_items, min_support)

    items = sorted(itemsets.keys())
    return list(recursive_eclat(frozenset(), items, min_support))

# Train the model
min_support = 2
frequent_itemsets = eclat([set(transaction) for transaction in df['Items']], min_support)

# Show the accuracy factors
print("Frequent Itemsets:")
for itemset, support in frequent_itemsets:
    print(f"{set(itemset)}: {support}")

# Visualize the data
itemsets, supports = zip(*frequent_itemsets)
itemsets = [' & '.join(itemset) for itemset in itemsets]

plt.bar(itemsets, supports)
plt.xlabel('Itemsets')
plt.ylabel('Support')
plt.title('Frequent Itemsets and their Support')
plt.xticks(rotation=90)
plt.show()

# Predict for user input
user_input = {'Milk', 'Bread'}
predicted_itemsets = [itemset for itemset, support in frequent_itemsets if user_input.issubset(itemset)]

print("Predicted Itemsets for user input:")
for itemset in predicted_itemsets:
    print(set(itemset))

# Visualize the prediction
predicted_itemsets_str = [' & '.join(itemset) for itemset in predicted_itemsets]
predicted_supports = [support for itemset, support in frequent_itemsets if user_input.issubset(itemset)]

plt.bar(predicted_itemsets_str, predicted_supports)
plt.xlabel('Predicted Itemsets')
plt.ylabel('Support')
plt.title('Predicted Itemsets and their Support')
plt.xticks(rotation=90)
plt.show()