import pandas as pd
from mlxtend.frequent_patterns import apriori, association_rules

import matplotlib.pyplot as plt

# Sample dataset
data = {'Milk': [1, 0, 1, 1, 0],
    'Bread': [1, 1, 0, 1, 1],
    'Butter': [0, 1, 1, 1, 0],
    'Cheese': [0, 0, 1, 0, 1]}

df = pd.DataFrame(data)

# Apply the Apriori algorithm
frequent_itemsets = apriori(df, min_support=0.6, use_colnames=True)

# Generate the association rules
rules = association_rules(frequent_itemsets, metric="lift", min_threshold=1)

# Display the rules
print(rules)

# Visualize the support, confidence, and lift of the rules
plt.scatter(rules['support'], rules['confidence'], alpha=0.5)
plt.xlabel('Support')
plt.ylabel('Confidence')
plt.title('Support vs Confidence')
plt.show()

plt.scatter(rules['support'], rules['lift'], alpha=0.5)
plt.xlabel('Support')
plt.ylabel('Lift')
plt.title('Support vs Lift')
plt.show()

# Predict for user input
user_input = {'Milk': 1, 'Bread': 0, 'Butter': 1, 'Cheese': 0}
user_df = pd.DataFrame([user_input])

# Find matching rules
matching_rules = rules[rules['antecedents'].apply(lambda x: all(item in user_df.columns[user_df.iloc[0] == 1] for item in x))]

# Display matching rules
print("Matching Rules:")
print(matching_rules)

# Visualize the matching rules
plt.scatter(matching_rules['support'], matching_rules['confidence'], alpha=0.5, color='red')
plt.xlabel('Support')
plt.ylabel('Confidence')
plt.title('Matching Rules: Support vs Confidence')
plt.show()

plt.scatter(matching_rules['support'], matching_rules['lift'], alpha=0.5, color='red')
plt.xlabel('Support')
plt.ylabel('Lift')
plt.title('Matching Rules: Support vs Lift')
plt.show()