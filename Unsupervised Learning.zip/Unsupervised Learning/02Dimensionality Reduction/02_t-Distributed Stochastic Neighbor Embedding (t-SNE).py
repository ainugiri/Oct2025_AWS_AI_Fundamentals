from sklearn.datasets import load_digits
from sklearn.manifold import TSNE
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

import matplotlib.pyplot as plt

# Load dataset
digits = load_digits()
X = digits.data
y = digits.target

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Apply t-SNE
tsne = TSNE(n_components=2, random_state=42)
X_train_tsne = tsne.fit_transform(X_train)
X_test_tsne = tsne.fit_transform(X_test)

# Train a KNN classifier on the t-SNE transformed data
knn = KNeighborsClassifier(n_neighbors=3)
knn.fit(X_train_tsne, y_train)

# Predict on the test set
y_pred = knn.predict(X_test_tsne)

# Calculate accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f'Accuracy: {accuracy * 100:.2f}%')

# Visualize the data
plt.figure(figsize=(12, 6))
plt.subplot(1, 2, 1)
plt.scatter(X_train_tsne[:, 0], X_train_tsne[:, 1], c=y_train, cmap='viridis', s=5)
plt.title('t-SNE visualization of training data')
plt.colorbar()

plt.subplot(1, 2, 2)
plt.scatter(X_test_tsne[:, 0], X_test_tsne[:, 1], c=y_test, cmap='viridis', s=5)
plt.title('t-SNE visualization of test data')
plt.colorbar()

plt.show()

# Predict for user input
def predict_user_input(input_data):
    input_data_tsne = tsne.fit_transform(input_data)
    prediction = knn.predict(input_data_tsne)
    input_data_tsne = tsne.transform(input_data)

# Example user input
user_input = X_test[:5]
user_prediction = predict_user_input(user_input)
print(f'User input predictions: {user_prediction}')
input_data_tsne = tsne.transform(user_input)
user_prediction = knn.predict(input_data_tsne)
# Visualize user input predictions
plt.figure(figsize=(6, 6))
plt.scatter(X_test_tsne[:, 0], X_test_tsne[:, 1], c=y_test, cmap='viridis', s=5)
plt.scatter(input_data_tsne[:, 0], input_data_tsne[:, 1], c='red', s=50, edgecolors='k')
plt.title('t-SNE visualization with user input predictions')
plt.colorbar()
plt.show()