import numpy as np
# import pandas as pd
import umap.umap_ as umap
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier

import matplotlib.pyplot as plt

# Load sample dataset
digits = load_digits()
data = digits.data
target = digits.target

# Standardize the data
scaler = StandardScaler()
data_scaled = scaler.fit_transform(data)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(data_scaled, target, test_size=0.3, random_state=42)

# Apply UMAP for dimensionality reduction
umap_model = umap.UMAP(n_neighbors=15, n_components=2, random_state=42)
X_train_umap = umap_model.fit_transform(X_train)
X_test_umap = umap_model.transform(X_test)

# Train a classifier on the reduced data
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train_umap, y_train)

# Predict and calculate accuracy
y_pred = knn.predict(X_test_umap)
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy * 100:.2f}%")

# Visualize the reduced data
plt.figure(figsize=(12, 6))
plt.scatter(X_train_umap[:, 0], X_train_umap[:, 1], c=y_train, cmap='Spectral', s=5)
plt.colorbar(boundaries=np.arange(11)-0.5).set_ticks(np.arange(10))
plt.title('UMAP projection of the Digits dataset')
plt.show()

# Function to predict and visualize user input
def predict_and_visualize(input_data):
    input_data_scaled = scaler.transform([input_data])
    input_data_umap = umap_model.transform(input_data_scaled)
    prediction = knn.predict(input_data_umap)
    
    plt.figure(figsize=(12, 6))
    plt.scatter(X_train_umap[:, 0], X_train_umap[:, 1], c=y_train, cmap='Spectral', s=5)
    plt.scatter(input_data_umap[:, 0], input_data_umap[:, 1], c='red', s=100, edgecolor='k')
    plt.colorbar(boundaries=np.arange(11)-0.5).set_ticks(np.arange(10))
    plt.title(f'UMAP projection with user input (predicted as {prediction[0]})')
    plt.show()

# Example user input
user_input = data[0]  # Replace with actual user input
predict_and_visualize(user_input)