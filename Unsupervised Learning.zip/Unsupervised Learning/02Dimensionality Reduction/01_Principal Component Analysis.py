import numpy as np
from sklearn.decomposition import PCA
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier

import matplotlib.pyplot as plt

# Load the Iris dataset
data = load_iris()
X = data.data
y = data.target

# Standardize the data
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.3, random_state=42)

# Apply PCA
pca = PCA(n_components=2)
X_train_pca = pca.fit_transform(X_train)
X_test_pca = pca.transform(X_test)

# Train a KNN classifier on the reduced data
knn = KNeighborsClassifier(n_neighbors=3)
knn.fit(X_train_pca, y_train)

# Predict and calculate accuracy
y_pred = knn.predict(X_test_pca)
accuracy = accuracy_score(y_test, y_pred)
print(f'Accuracy: {accuracy * 100:.2f}%')

# Visualize the PCA components
plt.figure(figsize=(8, 6))
for i, target_name in enumerate(data.target_names):
    plt.scatter(X_train_pca[y_train == i, 0], X_train_pca[y_train == i, 1], label=target_name)
plt.xlabel('First Principal Component')
plt.ylabel('Second Principal Component')
plt.legend()
plt.title('PCA of IRIS dataset')
plt.show()

# Predict for user input
user_input = np.array([[5.1, 3.5, 1.4, 0.2]])  # Example input
user_input_scaled = scaler.transform(user_input)
user_input_pca = pca.transform(user_input_scaled)
user_prediction = knn.predict(user_input_pca)
print(f'Predicted class for the user input: {data.target_names[user_prediction][0]}')

# Visualize the user input in the PCA plot
plt.figure(figsize=(8, 6))
for i, target_name in enumerate(data.target_names):
    plt.scatter(X_train_pca[y_train == i, 0], X_train_pca[y_train == i, 1], label=target_name)
plt.scatter(user_input_pca[0, 0], user_input_pca[0, 1], color='red', marker='x', s=100, label='User Input')
plt.xlabel('First Principal Component')
plt.ylabel('Second Principal Component')
plt.legend()
plt.title('PCA of IRIS dataset with User Input')
plt.show()