import numpy as np
from sklearn import svm
from sklearn.datasets import make_blobs
from sklearn.metrics import accuracy_score

import matplotlib.pyplot as plt

# Generate sample data
X, _ = make_blobs(n_samples=300, centers=1, cluster_std=0.60, random_state=0)
X = np.r_[X + 2, X - 2]

# Fit the model
clf = svm.OneClassSVM(nu=0.1, kernel="rbf", gamma=0.1)
clf.fit(X)

# Predict
y_pred_train = clf.predict(X)
n_error_train = y_pred_train[y_pred_train == -1].size

# Generate new data for testing
X_test, _ = make_blobs(n_samples=100, centers=1, cluster_std=0.60, random_state=0)
X_test = np.r_[X_test + 2, X_test - 2]
y_pred_test = clf.predict(X_test)
n_error_test = y_pred_test[y_pred_test == -1].size

# Accuracy
accuracy = accuracy_score(np.ones_like(y_pred_test), y_pred_test)
print(f'Accuracy: {accuracy * 100:.2f}%')
print(f'Training errors: {n_error_train}')
print(f'Test errors: {n_error_test}')

# Visualization
xx, yy = np.meshgrid(np.linspace(-5, 5, 500), np.linspace(-5, 5, 500))
Z = clf.decision_function(np.c_[xx.ravel(), yy.ravel()])
Z = Z.reshape(xx.shape)

plt.title("One-Class SVM")
plt.contourf(xx, yy, Z, levels=np.linspace(Z.min(), 0, 7), cmap=plt.cm.PuBu)
plt.contour(xx, yy, Z, levels=[0], linewidths=2, colors='darkred')
plt.scatter(X[:, 0], X[:, 1], c='white', s=20, edgecolor='k')
plt.scatter(X_test[:, 0], X_test[:, 1], c='blue', s=20, edgecolor='k')
plt.axis('tight')
plt.xlim((-5, 5))
plt.ylim((-5, 5))
plt.show()

# Predict for user input
user_input = np.array([[float(input("Enter X coordinate: ")), float(input("Enter Y coordinate: "))]])
user_pred = clf.predict(user_input)
print(f'User input is {"an anomaly" if user_pred == -1 else "normal"}')

# Visualization with user input
plt.title("One-Class SVM with User Input")
plt.contourf(xx, yy, Z, levels=np.linspace(Z.min(), 0, 7), cmap=plt.cm.PuBu)
plt.contour(xx, yy, Z, levels=[0], linewidths=2, colors='darkred')
plt.scatter(X[:, 0], X[:, 1], c='white', s=20, edgecolor='k')
plt.scatter(X_test[:, 0], X_test[:, 1], c='blue', s=20, edgecolor='k')
plt.scatter(user_input[:, 0], user_input[:, 1], c='red', s=100, edgecolor='k')
plt.axis('tight')
plt.xlim((-5, 5))
plt.ylim((-5, 5))
plt.show()