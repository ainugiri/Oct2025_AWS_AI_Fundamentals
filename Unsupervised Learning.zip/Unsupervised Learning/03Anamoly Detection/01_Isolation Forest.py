import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split

import matplotlib.pyplot as plt

# Generate synthetic data
np.random.seed(42)
X = 0.3 * np.random.randn(100, 2)
X_train = np.r_[X + 2, X - 2]
X_test = np.random.uniform(low=-4, high=4, size=(20, 2))

# Train Isolation Forest model
clf = IsolationForest(contamination=0.1, random_state=42)
clf.fit(X_train)

# Predict anomalies
y_pred_train = clf.predict(X_train)
y_pred_test = clf.predict(X_test)

# Convert predictions to binary (1 for normal, -1 for anomaly)
y_pred_train = np.where(y_pred_train == 1, 0, 1)
y_pred_test = np.where(y_pred_test == 1, 0, 1)

# Calculate accuracy
accuracy_train = accuracy_score(np.zeros(len(X_train)), y_pred_train)
accuracy_test = accuracy_score(np.ones(len(X_test)), y_pred_test)

print(f"Training Accuracy: {accuracy_train}")
print(f"Test Accuracy: {accuracy_test}")
print("Classification Report:")
print(classification_report(np.ones(len(X_test)), y_pred_test))

# Visualize the data
plt.scatter(X_train[:, 0], X_train[:, 1], c='blue', label='Training Data')
plt.scatter(X_test[:, 0], X_test[:, 1], c='red', label='Test Data')
plt.title("Isolation Forest Anomaly Detection")
plt.legend()
plt.show()

# Predict for user input
user_input = np.array([[float(input("Enter feature 1: ")), float(input("Enter feature 2: "))]])
user_pred = clf.predict(user_input)
user_pred = "Anomaly" if user_pred == -1 else "Normal"

# Visualize user input
plt.scatter(X_train[:, 0], X_train[:, 1], c='blue', label='Training Data')
plt.scatter(X_test[:, 0], X_test[:, 1], c='red', label='Test Data')
plt.scatter(user_input[:, 0], user_input[:, 1], c='green', label='User Input')
plt.title(f"User Input Prediction: {user_pred}")
plt.legend()
plt.show()