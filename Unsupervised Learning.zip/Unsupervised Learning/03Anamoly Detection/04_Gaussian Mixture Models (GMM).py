import numpy as np
from sklearn.mixture import GaussianMixture
from sklearn.datasets import make_blobs
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.model_selection import train_test_split

import matplotlib.pyplot as plt

# Generate synthetic data
X, y_true = make_blobs(n_samples=300, centers=3, cluster_std=0.60, random_state=0)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y_true, test_size=0.3, random_state=42)

# Fit the Gaussian Mixture Model
gmm = GaussianMixture(n_components=3, random_state=0)
gmm.fit(X_train)

# Predict the labels for the test set
y_pred = gmm.predict(X_test)

# Calculate accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f'Accuracy: {accuracy * 100:.2f}%')

# Confusion matrix
conf_matrix = confusion_matrix(y_test, y_pred)
print('Confusion Matrix:')
print(conf_matrix)

# Visualize the data
plt.scatter(X[:, 0], X[:, 1], c=y_true, s=40, cmap='viridis')
plt.title('Original Data')
plt.show()

plt.scatter(X_test[:, 0], X_test[:, 1], c=y_pred, s=40, cmap='viridis')
plt.title('GMM Predicted Data')
plt.show()

# Predict for user input
user_input = np.array([[0.5, 2.5]])
user_pred = gmm.predict(user_input)
print(f'User input prediction: {user_pred[0]}')

# Visualize user input prediction
plt.scatter(X[:, 0], X[:, 1], c=y_true, s=40, cmap='viridis')
plt.scatter(user_input[:, 0], user_input[:, 1], c='red', s=100, marker='x')
plt.title('User Input Prediction')
plt.show()