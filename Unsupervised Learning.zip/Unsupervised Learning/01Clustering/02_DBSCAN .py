import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import DBSCAN
from sklearn.datasets import make_moons

# Step 1: Generate synthetic dataset
# Create a dataset with two interleaving half-moon shapes
n_samples = 300
noise_level = 0.05

X, y = make_moons(n_samples=n_samples, noise=noise_level, random_state=42)

# Step 2: Apply DBSCAN
# Define DBSCAN parameters
epsilon = 0.2  # Maximum distance between points to be considered neighbors
min_samples = 5  # Minimum number of points to form a dense region

dbscan = DBSCAN(eps=epsilon, min_samples=min_samples)
y_pred = dbscan.fit_predict(X)

# Step 3: Visualize the clusters
# Identify noise points
core_samples_mask = np.zeros_like(y_pred, dtype=bool)
core_samples_mask[dbscan.core_sample_indices_] = True
unique_labels = set(y_pred)

# Plot the results
plt.figure(figsize=(8, 6))
colors = [plt.cm.Spectral(each) for each in np.linspace(0, 1, len(unique_labels))]
for k, col in zip(unique_labels, colors):
    if k == -1:
        # Noise points are black
        col = [0, 0, 0, 1]

    class_member_mask = (y_pred == k)

    xy = X[class_member_mask & core_samples_mask]
    plt.plot(xy[:, 0], xy[:, 1], 'o', markerfacecolor=tuple(col), markeredgecolor='k', markersize=10)

    xy = X[class_member_mask & ~core_samples_mask]
    plt.plot(xy[:, 0], xy[:, 1], 'o', markerfacecolor=tuple(col), markeredgecolor='k', markersize=6)

plt.title('DBSCAN Clustering')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.grid()
plt.show()
