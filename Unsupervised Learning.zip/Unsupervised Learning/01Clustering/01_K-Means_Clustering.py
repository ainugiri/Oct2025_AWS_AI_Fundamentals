import numpy as np
from sklearn.datasets import load_digits
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.preprocessing import scale

import matplotlib.pyplot as plt

# Load the digits dataset
digits = load_digits()
data = scale(digits.data)

# Define the number of clusters (10 digits)
n_digits = len(np.unique(digits.target))

# Initialize KMeans
kmeans = KMeans(n_clusters=n_digits, random_state=42)
kmeans.fit(data)

# Predict the cluster for each data point
clusters = kmeans.predict(data)

# Map the cluster labels to the actual digit labels
labels = np.zeros_like(clusters)
for i in range(n_digits):
    mask = (clusters == i)
    labels[mask] = np.bincount(digits.target[mask]).argmax()

# Calculate the accuracy
accuracy = accuracy_score(digits.target, labels)
print(f'Accuracy: {accuracy * 100:.2f}%')

# Show the confusion matrix
conf_matrix = confusion_matrix(digits.target, labels)
print('Confusion Matrix:')
print(conf_matrix)

# Visualize the data using PCA
reduced_data = PCA(n_components=2).fit_transform(data)
plt.figure(figsize=(8, 6))
plt.scatter(reduced_data[:, 0], reduced_data[:, 1], c=clusters, cmap='viridis', edgecolor='k', s=50)
plt.title('K-Means Clustering of MNIST Digits')
plt.xlabel('PCA Component 1')
plt.ylabel('PCA Component 2')
plt.colorbar()
plt.show()

# Function to predict and visualize user input
def predict_and_visualize(input_data):
    input_data = scale(input_data.reshape(1, -1))
    cluster = kmeans.predict(input_data)
    label = np.bincount(digits.target[clusters == cluster]).argmax()
    print(f'Predicted label: {label}')
    
    # Visualize the input data
    plt.imshow(input_data.reshape(8, 8), cmap='gray')
    plt.title(f'Predicted label: {label}')
    plt.show()

# Example usage of predict_and_visualize
# Here we use the first image from the dataset as an example
predict_and_visualize(digits.data[0])