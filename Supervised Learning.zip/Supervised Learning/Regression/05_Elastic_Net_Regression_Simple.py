import numpy as np
from sklearn.linear_model import ElasticNet
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

import matplotlib.pyplot as plt

# Generate a more appropriate dataset for Elastic Net Regression
np.random.seed(0)
X = np.random.rand(100, 1) * 10
y = 4 + 3 * X + np.random.randn(100, 1)

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

# Train the Elastic Net Regression model
elastic_net = ElasticNet(alpha=1.0, l1_ratio=0.5)
elastic_net.fit(X_train, y_train)

# Predict using the trained model
y_pred = elastic_net.predict(X_test)

# Evaluate the model
mse = mean_squared_error(y_test, y_pred)
print("Mean Squared Error:", mse)

# Visualize the data and the regression line
plt.scatter(X, y, color='blue', label='Data points')
plt.plot(X_test, y_pred, color='red', linewidth=2, label='Elastic Net Regression Line')
plt.xlabel('X')
plt.ylabel('y')
plt.title('Elastic Net Regression')
plt.legend()
plt.show()

# Predict for user input
user_input = float(input("Enter a value for prediction: "))
user_prediction = elastic_net.predict([[user_input]])
print(f"Predicted value for {user_input} is {user_prediction[0]}")

# Visualize the user input prediction
plt.scatter(X, y, color='blue', label='Data points')
plt.plot(X_test, y_pred, color='red', linewidth=2, label='Elastic Net Regression Line')
plt.scatter(user_input, user_prediction, color='green', s=100, label='User Prediction')
plt.xlabel('X')
plt.ylabel('y')
plt.title('Elastic Net Regression with User Prediction')
plt.legend()
plt.show()