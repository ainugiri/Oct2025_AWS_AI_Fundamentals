import numpy as np
from sklearn.linear_model import Lasso
from sklearn.model_selection import train_test_split

import matplotlib.pyplot as plt

# Generate a more satisfying dataset
np.random.seed(0)
X = np.random.rand(100, 1) * 10  # Features
y = 4 + 3 * X + np.random.randn(100, 1)

# Visualize the data
plt.scatter(X, y, color='blue', label='Data points')
plt.xlabel('Feature')
plt.ylabel('Target')
plt.title('Generated Data')
plt.legend()
plt.show()

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

# Train the Lasso Regression model
lasso = Lasso(alpha=0.1)
lasso.fit(X_train, y_train)

# Predict for the user input
user_input = float(input("Enter a value for prediction: "))
user_prediction = lasso.predict([[user_input]])

# Visualize the prediction
plt.scatter(X, y, color='blue', label='Data points')
plt.plot(X, lasso.predict(X), color='red', label='Lasso Regression Line')
plt.scatter([user_input], user_prediction, color='green', label='User Prediction')
plt.xlabel('Feature')
plt.ylabel('Target')
plt.title('Lasso Regression with User Prediction')
plt.legend()
plt.show()

print(f"Prediction for input {user_input}: {user_prediction[0]}")