import numpy as np

import matplotlib.pyplot as plt

# Sample data
X = np.array([1, 2, 3, 4, 5])
y = np.array([1, 3, 2, 5, 4])

# Linear regression parameters
m = 0.5  # slope
b = 0.5  # intercept

# Predicted values
y_pred = m * X + b

# Loss function (Mean Squared Error)
def mean_squared_error(y_true, y_pred):
    return np.mean((y_true - y_pred) ** 2)

# Calculate loss
loss = mean_squared_error(y, y_pred)

# Print loss
print(f"Mean Squared Error: {loss}")

# Plotting the data and the regression line
plt.scatter(X, y, color='blue', label='Data points')
plt.plot(X, y_pred, color='red', label='Regression line')
plt.xlabel('X')
plt.ylabel('y')
plt.title('Linear Regression with Loss Function')
plt.legend()
plt.show()

# Get input from user to predict value
x_input = float(input("Enter a value for X to predict y: "))

# Predict the value of y using the linear regression model
y_output = m * x_input + b

# Print the predicted value
print(f"The predicted value of y for X = {x_input} is: {y_output}")

# Plotting the data and the regression line
plt.scatter(X, y, color='blue', label='Data points')
plt.plot(x_input, y_output, color='red', label='Regression line')
plt.xlabel('X')
plt.ylabel('y')
plt.title('Linear Regression with Loss Function')
plt.legend()
plt.show()