import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsRegressor
from sklearn.metrics import mean_squared_error

import matplotlib.pyplot as plt

# Generate a more appropriate dataset for K-Nearest Neighbors Regression
np.random.seed(0)
X = np.sort(5 * np.random.rand(100, 1), axis=0)
y = np.sin(X).ravel() + np.random.normal(0, 0.2, X.shape[0])

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the K-Nearest Neighbors Regression model
knn = KNeighborsRegressor(n_neighbors=5)
knn.fit(X_train, y_train)

# Predict the values for the test set
y_pred = knn.predict(X_test)

# Show the accuracy factors, how much it deviates from the actual
mse = mean_squared_error(y_test, y_pred)
print(f"Mean Squared Error: {mse}")

# Visualize the data
plt.scatter(X, y, color='darkorange', label='data')
plt.plot(X_test, y_pred, color='navy', label='prediction')
plt.xlabel('data')
plt.ylabel('target')
plt.title('K-Nearest Neighbors Regression')
plt.legend()
plt.show()

# Predict for the user input and show it in visualization
user_input = np.array([[float(input("Enter a value for prediction: "))]])
user_pred = knn.predict(user_input)

plt.scatter(X, y, color='darkorange', label='data')
plt.plot(X_test, y_pred, color='navy', label='prediction')
plt.scatter(user_input, user_pred, color='red', label='user prediction')
plt.xlabel('data')
plt.ylabel('target')
plt.title('K-Nearest Neighbors Regression with User Prediction')
plt.legend()
plt.show()