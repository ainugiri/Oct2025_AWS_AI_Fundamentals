import numpy as np
from sklearn.linear_model import Ridge
from sklearn.model_selection import train_test_split

import matplotlib.pyplot as plt

# Generate sample data
np.random.seed(0)
X = 2 * np.random.rand(100, 1)
y = 4 + 3 * X + np.random.randn(100, 1)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create and train the Ridge Regression model
ridge_reg = Ridge(alpha=1.0)
ridge_reg.fit(X_train, y_train)

# Make predictions
y_pred = ridge_reg.predict(X_test)

# Plot the results
plt.scatter(X, y, color='blue', label='Data points')
plt.plot(X_test, y_pred, color='red', linewidth=2, label='Ridge Regression Line')
plt.xlabel('X')
plt.ylabel('y')
plt.title('Ridge Regression')
plt.legend()
plt.show()
# Get user input
user_input = float(input("Enter a value for X: "))

# Predict using the Ridge Regression model
user_pred = ridge_reg.predict([[user_input]])

# Plot the user input and prediction
plt.scatter(X, y, color='blue', label='Data points')
plt.scatter(user_input, user_pred, color='green', s=100, label='User Prediction')
plt.plot(X_test, y_pred, color='red', linewidth=2, label='Ridge Regression Line')
plt.plot(user_input, user_pred, color='yellow', linewidth=2, label='Ridge Regression Line')
plt.legend()
plt.show()

print(f"Predicted value for X={user_input} is y={user_pred[0][0]}")