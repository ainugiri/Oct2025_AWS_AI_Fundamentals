# Sample Dataset
"""
This script performs linear regression to predict the price of a smartphone based on its features such as RAM, Storage, Battery, Camera, and Processor Speed.
Steps:
1. Load the dataset into a DataFrame.
2. Split the data into training and testing sets.
3. Train a Linear Regression model using the training data.
4. Evaluate the model using Mean Squared Error (MSE) and R-squared metrics.
5. Plot the actual vs predicted prices.
6. Predict the price based on user input features.
Functions:
- mean_squared_error: Calculates the average of the squares of the errors between actual and predicted values.
- r2_score: Provides the proportion of the variance in the dependent variable that is predictable from the independent variables.
Explain a loss function and how it works:
A loss function measures how well the model's predictions match the actual data. In linear regression, the Mean Squared Error (MSE) is commonly used as the loss function. It calculates the average of the squared differences between the predicted and actual values. The goal is to minimize this error to improve the model's accuracy.
Define and describe how gradient descent finds the optimal model parameters:
Gradient descent is an optimization algorithm used to minimize the loss function. It iteratively adjusts the model parameters (weights) in the direction that reduces the loss. Starting with initial random weights, it calculates the gradient (partial derivatives) of the loss function with respect to each parameter. The parameters are then updated by subtracting the product of the learning rate and the gradient. This process is repeated until the loss converges to a minimum value.
Describe how to tune hyperparameters to efficiently train a linear model:
Hyperparameter tuning involves selecting the best set of hyperparameters to optimize the model's performance. For linear regression, key hyperparameters include the learning rate and regularization parameters. Techniques such as grid search, random search, and cross-validation can be used to systematically explore different hyperparameter values. Cross-validation helps in assessing the model's performance on different subsets of the data, ensuring that the chosen hyperparameters generalize well to unseen data.
"""
# RAM (GB)	Storage (GB)	Battery (mAh)	Camera (MP)	Processor Speed (GHz)	Price (USD)
# 4	64	4000	12	2.0	300
# 6	128	4500	48	2.2	500
# 8	128	5000	64	2.3	700
# 6	64	3500	16	1.8	400
# 8	256	4500	108	2.5	900
# 12	512	6000	108	3.0	1200
# 4	32	3000	8	1.6	200
# 6	128	4000	48	2.1	550
# 8	256	5000	64	2.4	750
# 12	512	7000	108	3.2	1300
# Feature Details
# RAM (GB): Random Access Memory, influences multitasking capabilities.
# Storage (GB): Internal storage space, a key factor for users who install apps or store media.
# Battery (mAh): Battery capacity, higher capacity often correlates with better battery life.
# Camera (MP): Megapixels of the main camera, significant for photography enthusiasts.
# Processor Speed (GHz): Clock speed of the processor, affecting overall performance.
# Price (USD): Target variable for regression.
# Linear Regression Task
# The goal is to predict the Price (USD) based on the features.

# Steps to Build the Model
# Data Preparation:

# Load the dataset into a DataFrame.
# Perform feature scaling if needed (e.g., Standardization or Min-Max Scaling).
# Train-Test Split:

# Split the data into training (80%) and testing (20%) sets.
# Model Training:

# Use a library like scikit-learn to fit a Linear Regression model.
# Example: model = LinearRegression().fit(X_train, y_train)
# Model Evaluation:

# Evaluate performance using metrics like Mean Squared Error (MSE), R-squared, etc.

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt
# Sample Data
data = {
    'RAM (GB)': [4, 6, 8, 6, 8, 12, 4, 6, 8, 12],
    'Storage (GB)': [64, 128, 128, 64, 256, 512, 32, 128, 256, 512],
    'Battery (mAh)': [4000, 4500, 5000, 3500, 4500, 6000, 3000, 4000, 5000, 7000],
    'Camera (MP)': [12, 48, 64, 16, 108, 108, 8, 48, 64, 108],
    'Processor Speed (GHz)': [2.0, 2.2, 2.3, 1.8, 2.5, 3.0, 1.6, 2.1, 2.4, 3.2],
    'Price (USD)': [300, 500, 700, 400, 900, 1200, 200, 550, 750, 1300]
}

# Create DataFrame
df = pd.DataFrame(data)

# Features and Target
X = df[['RAM (GB)', 'Storage (GB)', 'Battery (mAh)', 'Camera (MP)', 'Processor Speed (GHz)']]
y = df['Price (USD)']

# Split Data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Linear Regression Model
model = LinearRegression()
model.fit(X_train, y_train)

# Predictions
y_pred = model.predict(X_test)

# Evaluation
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print("Mean Squared Error:", mse)
print("R-Squared:", r2)

# Plot Predictions line
plt.scatter(y_test, y_pred)
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'k--', lw=2)
plt.xlabel("Actual Prices (USD)")
plt.ylabel("Predicted Prices (USD)")
plt.title("Actual Prices vs Predicted Prices")
plt.show()

# predicted prices are close to the actual prices, indicating the model's effectiveness in predicting the target variable.
RAM_input = int(input("Enter RAM (GB): "))
Storage_input = int(input("Enter Storage (GB): "))
Battery_input = int(input("Enter Battery (mAh): "))
Camera_input = int(input("Enter Camera (MP): "))
Processor_input = int(input("Enter Processor Speed (GHz): "))

price = model.predict([[RAM_input, Storage_input, Battery_input, Camera_input, Processor_input]])
print("Predicted Price (USD):", price[0])

# Output
# Mean Squared Error: 1.748287853974673e-25
# R-Squared: 1.0
# The model achieved a perfect R-squared value of 1.0, indicating a perfect fit. The Mean Squared Error is close to zero, further confirming the model's accuracy. The scatter plot shows a linear relationship between the actual and predicted prices, indicating the model's effectiveness in predicting the target variable.
# Note: In practice, real-world datasets may not exhibit such perfect results due to noise, outliers, or other factors. It's essential to evaluate the model's performance on diverse datasets and consider additional techniques like regularization to prevent overfitting.

