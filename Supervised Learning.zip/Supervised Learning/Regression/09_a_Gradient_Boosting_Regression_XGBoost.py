import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
from xgboost import XGBRegressor

import matplotlib.pyplot as plt

# Generate a synthetic dataset
np.random.seed(42)
X = np.random.rand(100, 1) * 10  # Features
y = 2 * X.squeeze() + 1 + np.random.randn(100) * 2  # Target with noise

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the Gradient Boosting Regression model using XGBoost
model = XGBRegressor(n_estimators=100, learning_rate=0.1, max_depth=3, random_state=42)
model.fit(X_train, y_train)

# Make predictions
y_pred = model.predict(X_test)

# Calculate accuracy factors
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f"Mean Squared Error: {mse}")
print(f"R^2 Score: {r2}")

# Visualize the data
plt.scatter(X, y, color='blue', label='Actual data')
plt.scatter(X_test, y_pred, color='red', label='Predicted data')
plt.xlabel('Feature')
plt.ylabel('Target')
plt.title('Gradient Boosting Regression with XGBoost')
plt.legend()
plt.show()

# Predict for user input and show it in visualization
user_input = np.array([[float(input("Enter a value for prediction: "))]])
user_pred = model.predict(user_input)

plt.scatter(X, y, color='blue', label='Actual data')
plt.scatter(X_test, y_pred, color='red', label='Predicted data')
plt.scatter(user_input, user_pred, color='green', label='User prediction')
plt.xlabel('Feature')
plt.ylabel('Target')
plt.title('Gradient Boosting Regression with XGBoost')
plt.legend()
plt.show()

print(f"Prediction for user input {user_input[0][0]}: {user_pred[0]}")