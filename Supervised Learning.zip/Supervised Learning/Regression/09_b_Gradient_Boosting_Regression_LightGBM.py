import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import lightgbm as lgb

import matplotlib.pyplot as plt

# Generate a synthetic dataset
np.random.seed(42)
X = np.random.rand(1000, 1) * 10  # Features
y = 2 * X.squeeze() + 1 + np.random.randn(1000) * 2  # Target with some noise

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create and train the LightGBM model
train_data = lgb.Dataset(X_train, label=y_train)
params = {
    'objective': 'regression',
    'metric': 'rmse',
    'boosting_type': 'gbdt',
    'num_leaves': 31,
    'learning_rate': 0.05,
    'feature_fraction': 0.9
}
gbm = lgb.train(params, train_data, num_boost_round=100)

# Predict on the test set
y_pred = gbm.predict(X_test)

# Calculate accuracy factors
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
print(f'Mean Squared Error: {mse}')
print(f'R^2 Score: {r2}')

# Visualize the data
plt.figure(figsize=(10, 6))
plt.scatter(X_test, y_test, color='blue', label='Actual')
plt.scatter(X_test, y_pred, color='red', label='Predicted')
plt.title('Actual vs Predicted')
plt.xlabel('Feature')
plt.ylabel('Target')
plt.legend()
plt.show()

# Predict for user input and show it in visualization
user_input = float(input("Enter a value for prediction: "))
user_pred = gbm.predict(np.array([[user_input]]))

plt.figure(figsize=(10, 6))
plt.scatter(X_test, y_test, color='blue', label='Actual')
plt.scatter(X_test, y_pred, color='red', label='Predicted')
plt.scatter(user_input, user_pred, color='green', label='User Prediction', s=100)
plt.title('Actual vs Predicted with User Input')
plt.xlabel('Feature')
plt.ylabel('Target')
plt.legend()
plt.show()

print(f'Prediction for input {user_input}: {user_pred[0]}')