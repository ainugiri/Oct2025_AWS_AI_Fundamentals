import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score

import matplotlib.pyplot as plt

# Create a dataset
np.random.seed(42)
X = np.random.rand(1000, 1) * 10  # Features
y = 2 * X.squeeze() + 1 + np.random.randn(1000) * 2  # Target variable with some noise

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the Random Forest Regression model
regressor = RandomForestRegressor(n_estimators=100, random_state=42)
regressor.fit(X_train, y_train)

# Predict on the test set
y_pred = regressor.predict(X_test)

# Show accuracy factors
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
print(f"Mean Squared Error: {mse}")
print(f"R^2 Score: {r2}")

# Visualize the data
plt.scatter(X, y, color='blue', label='Actual data')
plt.scatter(X_test, y_pred, color='red', label='Predicted data')
plt.title('Random Forest Regression')
plt.xlabel('Feature')
plt.ylabel('Target')
plt.legend()
plt.show()

# Predict for user input
user_input = float(input("Enter a value for prediction: "))
user_prediction = regressor.predict(np.array([[user_input]]))
print(f"Prediction for {user_input}: {user_prediction[0]}")

# Visualize the prediction
plt.scatter(X, y, color='blue', label='Actual data')
plt.scatter(X_test, y_pred, color='red', label='Predicted data')
plt.scatter(user_input, user_prediction, color='green', label='User prediction')
plt.title('Random Forest Regression with User Prediction')
plt.xlabel('Feature')
plt.ylabel('Target')
plt.legend()
plt.show()