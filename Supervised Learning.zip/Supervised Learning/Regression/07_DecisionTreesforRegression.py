import numpy as np
from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score

import matplotlib.pyplot as plt

# Generate a more appropriate dataset for Decision Trees for Regression
np.random.seed(0)
X = np.sort(5 * np.random.rand(80, 1), axis=0)
y = np.sin(X).ravel()
y[::5] += 1 * (0.5 - np.random.rand(16))

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the model
regressor = DecisionTreeRegressor(max_depth=5)
regressor.fit(X_train, y_train)

# Predict on the test set
y_pred = regressor.predict(X_test)

# Show the accuracy factors
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
print(f"Mean Squared Error: {mse}")
print(f"R^2 Score: {r2}")

# Visualize the data
X_grid = np.arange(0.0, 5.0, 0.01)[:, np.newaxis]
y_grid_pred = regressor.predict(X_grid)

plt.scatter(X, y, color='red', label='Data')
plt.plot(X_grid, y_grid_pred, color='blue', label='Model Prediction')
plt.xlabel('X')
plt.ylabel('y')
plt.title('Decision Tree Regression')
plt.legend()
plt.show()

# Predict for the user input and show it in visualization
user_input = float(input("Enter a value for prediction: "))
user_pred = regressor.predict(np.array([[user_input]]))
print(f"Prediction for {user_input}: {user_pred[0]}")

plt.scatter(X, y, color='red', label='Data')
plt.plot(X_grid, y_grid_pred, color='blue', label='Model Prediction')
plt.scatter(user_input, user_pred, color='green', label='User Prediction', marker='x', s=100)
plt.xlabel('X')
plt.ylabel('y')
plt.title('Decision Tree Regression with User Prediction')
plt.legend()
plt.show()