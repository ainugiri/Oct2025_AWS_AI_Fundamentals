import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import mean_squared_error, r2_score

import matplotlib.pyplot as plt

# Generate synthetic real-time data
np.random.seed(42)
X = np.random.rand(10000, 1) * 10  # Features
y = 2.5 * X.squeeze() + np.random.randn(10000) * 2  # Target with some noise

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Standardize the data
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Create and train the neural network model
model = MLPRegressor(hidden_layer_sizes=(50, 50), max_iter=1000, random_state=42)
model.fit(X_train_scaled, y_train)

# Predict and evaluate the model
y_pred_train = model.predict(X_train_scaled)
y_pred_test = model.predict(X_test_scaled)

# Calculate accuracy factors
mse_train = mean_squared_error(y_train, y_pred_train)
mse_test = mean_squared_error(y_test, y_pred_test)
r2_train = r2_score(y_train, y_pred_train)
r2_test = r2_score(y_test, y_pred_test)

print(f"Training MSE: {mse_train:.2f}")
print(f"Testing MSE: {mse_test:.2f}")
print(f"Training R2 Score: {r2_train:.2f}")
print(f"Testing R2 Score: {r2_test:.2f}")

# Visualize the data
plt.figure(figsize=(14, 6))

# Training data
plt.subplot(1, 2, 1)
plt.scatter(X_train, y_train, color='blue', label='Actual')
plt.scatter(X_train, y_pred_train, color='red', label='Predicted')
plt.title('Training Data')
plt.xlabel('Feature')
plt.ylabel('Target')
plt.legend()

# Testing data
plt.subplot(1, 2, 2)
plt.scatter(X_test, y_test, color='blue', label='Actual')
plt.scatter(X_test, y_pred_test, color='red', label='Predicted')
plt.title('Testing Data')
plt.xlabel('Feature')
plt.ylabel('Target')
plt.legend()

plt.show()

# Predict for user input
user_input = float(input("Enter a value for prediction: "))
user_input_scaled = scaler.transform([[user_input]])
user_prediction = model.predict(user_input_scaled)
print(f"Predicted value for input {user_input}: {user_prediction[0]:.2f}")

# Visualize the prediction
plt.scatter(X, y, color='blue', label='Actual Data')
plt.scatter(user_input, user_prediction, color='green', label='User Prediction', s=100)
plt.title('Neural Network Regression')
plt.xlabel('Feature')
plt.ylabel('Target')
plt.legend()
plt.show()