import matplotlib.pyplot as plt
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression, Lasso
from sklearn.pipeline import make_pipeline
import numpy as np

# Generate a more appropriate dataset for polynomial regression
np.random.seed(0)
X = np.random.rand(100, 1) * 10  # Random values between 0 and 10
y = 2 * X**2 + 3 * X + 5 + np.random.randn(100, 1) * 10  # Quadratic relationship with noise
print(X.shape, y.shape)
print(X[:5], y[:5])

# Train the model
degree = 2
polynomial_features = PolynomialFeatures(degree=degree)
linear_regression = LinearRegression()
lasso_regression = Lasso(alpha=0.1)

pipeline = make_pipeline(polynomial_features, linear_regression)
pipeline_lasso = make_pipeline(polynomial_features, lasso_regression)

pipeline.fit(X, y)
pipeline_lasso.fit(X, y)

# Visualize the data
plt.scatter(X, y, color='blue', label='Data points')

# Generate a range of values for X to predict and visualize
X_range = np.linspace(0, 10, 100).reshape(-1, 1)
y_pred = pipeline.predict(X_range)
y_pred_lasso = pipeline_lasso.predict(X_range)

plt.plot(X_range, y_pred, color='red', label='Polynomial Regression')
plt.plot(X_range, y_pred_lasso, color='green', label='Lasso Regression')
plt.xlabel('X')
plt.ylabel('y')
plt.title('Polynomial Regression vs Lasso Regression')
plt.legend()
plt.show()

# Predict for user input
user_input = float(input("Enter a value for X to predict: "))
user_prediction = pipeline.predict([[user_input]])
user_prediction_lasso = pipeline_lasso.predict([[user_input]])

print(f"Polynomial Regression Prediction for {user_input}: {user_prediction[0][0]}")
print(f"Lasso Regression Prediction for {user_input}: {user_prediction_lasso[0]}")

# Visualize the user input
plt.scatter(X, y, color='blue', label='Data points')
plt.plot(X_range, y_pred, color='red', label='Polynomial Regression')
plt.plot(X_range, y_pred_lasso, color='green', label='Lasso Regression')
plt.scatter([user_input], user_prediction, color='red', label='User Prediction (Polynomial)')
plt.scatter([user_input], user_prediction_lasso, color='green', label='User Prediction (Lasso)')
plt.xlabel('X')
plt.ylabel('y')
plt.title('Polynomial Regression vs Lasso Regression with User Prediction')
plt.legend()
plt.show()