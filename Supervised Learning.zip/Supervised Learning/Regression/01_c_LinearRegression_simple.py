import numpy as np
from sklearn.linear_model import LinearRegression

import matplotlib.pyplot as plt

# Sample data: age of the car (in years) and price (in dollars)
age_of_car = np.array([1, 1, 1, 1, 1, 1, 1, 1, 1, 
                       2, 2, 2, 2, 2, 2, 2, 2, 2, 
                       3, 3, 3, 3, 3, 3, 3, 3, 3, 
                       4, 4, 4, 4, 4, 4, 4, 4, 4, 
                       5, 5, 5, 5, 5, 5, 5, 5, 5, 
                       6, 6, 6, 6, 6, 6, 6, 6, 6,
                       7, 7, 7, 7, 7, 7, 7, 7, 7, 
                       8, 8, 8, 8, 8, 8, 8, 8, 8, 
                       9, 9, 9, 9, 9, 9, 9, 9, 9, 
                       10, 10, 10, 10, 10, 10,10, 10, 10]).reshape(-1, 1)
price_of_car = np.array([
                    20000,19900,20100,19950,20050,20000,19950,20050,20000,
                    19000,18900,19100,19950,19050,19000,18950,19050,19000,
                    18000,17900,18100,18950,18050,18000,17950,18050,18000,
                    17000,16900,17100,17950,17050,17000,16950,17050,17000,
                    16000,15900,16100,16950,16050,16000,15950,16050,16000,
                    15000,14900,15100,15950,15050,15000,14950,15050,15000,
                    14000,13900,14100,14950,14050,14000,13950,14050,14000,
                    13000,12900,13100,13950,13050,13000,12950,13050,13000,
                    12000,11900,12100,12950,12050,12000,11950,12050,12000,
                    11000,10900,11100,11950,11050,11000,10950,11050,11000
                    ]).reshape(-1, 1)

# Create and train the model
model = LinearRegression()
model.fit(age_of_car, price_of_car)

# Predict prices for the given ages
predicted_prices = model.predict(age_of_car)

# Plot the results
plt.scatter(age_of_car, price_of_car, color='blue', label='Actual Prices')
plt.plot(age_of_car, predicted_prices, color='red', label='Predicted Prices')
plt.xlabel('Age of Car (years)')
plt.ylabel('Price of Car (dollars)')
plt.title('Linear Regression: Age of Car vs. Price')
plt.legend()
plt.show()

# Print the model parameters
print(f"Intercept: {model.intercept_}")
print(f"Coefficient: {model.coef_[0]}")
# Get user input for the age of the car
user_input = float(input("Enter the age of the car (in years): "))
user_input_array = np.array([[user_input]])

# Predict the price for the user input
predicted_price = model.predict(user_input_array)
print(f"Predicted price for a {user_input}-year-old car is: ${predicted_price[0][0]:.2f}")

# Plot the results again with the user input
plt.scatter(age_of_car, price_of_car, color='blue', label='Actual Prices')
plt.plot(age_of_car, predicted_prices, color='red', label='Predicted Prices')
plt.scatter(user_input, predicted_price, color='green', label='User Input Prediction')
plt.xlabel('Age of Car (years)')
plt.ylabel('Price of Car (dollars)')
plt.title('Linear Regression: Age of Car vs. Price')
plt.legend()
plt.show()