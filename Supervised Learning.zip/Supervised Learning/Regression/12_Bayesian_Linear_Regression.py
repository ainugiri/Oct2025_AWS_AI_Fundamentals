import numpy as np
from sklearn.linear_model import BayesianRidge
from sklearn.metrics import mean_squared_error, r2_score

import matplotlib.pyplot as plt

# Generate synthetic data
np.random.seed(0)
X = np.random.normal(0, 1, 100)
y = 4 * X + np.random.normal(0, 1, 100)

# Reshape data
X = X[:, np.newaxis]

# Train Bayesian Ridge Regression model
model = BayesianRidge()
model.fit(X, y)

# Predict using the model
y_pred = model.predict(X)

# Calculate accuracy factors
mse = mean_squared_error(y, y_pred)
r2 = r2_score(y, y_pred)

print(f"Mean Squared Error: {mse}")
print(f"R^2 Score: {r2}")

# Visualize the data
plt.scatter(X, y, color='blue', label='Actual data')
plt.plot(X, y_pred, color='red', label='Fitted line')
plt.title('Bayesian Linear Regression')
plt.xlabel('X')
plt.ylabel('y')
plt.legend()
plt.show()

# Predict for user input
user_input = float(input("Enter a value for prediction: "))
user_pred = model.predict([[user_input]])
print(f"Prediction for {user_input}: {user_pred[0]}")

# Visualize the prediction
plt.scatter(X, y, color='blue', label='Actual data')
plt.plot(X, y_pred, color='red', label='Fitted line')
plt.scatter(user_input, user_pred, color='green', label='User prediction')
plt.title('Bayesian Linear Regression with User Prediction')
plt.xlabel('X')
plt.ylabel('y')
plt.legend()
plt.show()