import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import mean_squared_error, r2_score

import matplotlib.pyplot as plt

# Generate synthetic data
np.random.seed(42)
X = np.array([[np.random.randint(4, 16), np.random.randint(8, 16), np.random.choice([64, 128, 256, 512]), np.random.uniform(5, 7)] for _ in range(1000)]) # 1000 samples, 4 features: ram, camera, storage, displaysize
y = 300 * X[:, 0] + 200 * X[:, 1] + 150 * X[:, 2] + 100 * X[:, 3] + np.random.randn(1000) * 10  # Linear relation with noise

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Standardize the data
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train the model
model = MLPRegressor(hidden_layer_sizes=(10, 10), max_iter=1000, random_state=42)
model.fit(X_train_scaled, y_train)

# Predict and evaluate
y_pred = model.predict(X_test_scaled)
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f"Mean Squared Error: {mse}")
print(f"R^2 Score: {r2}")

# Visualize the results
plt.scatter(y_test, y_pred)
plt.xlabel("Actual Values")
plt.ylabel("Predicted Values")
plt.title("Actual vs Predicted Values")
plt.show()

# Predict for user input
user_input = np.array([[8, 12, 256, 6.5]])  # Example user input: ram, camera, storage, displaysize
user_input_scaled = scaler.transform(user_input)
user_prediction = model.predict(user_input_scaled)

print(f"Prediction for user input {user_input}: {user_prediction}")

# Visualize the user input prediction
plt.scatter(y_test, y_pred, label="Test Data")
plt.scatter(user_input[0, 0], user_prediction, color='red', label="User Input Prediction")
plt.xlabel("Feature 1 (ram)")
plt.ylabel("Predicted Value (price)")
plt.legend()
plt.title("User Input Prediction Visualization")
plt.show()
