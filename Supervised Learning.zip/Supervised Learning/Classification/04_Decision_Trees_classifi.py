import pandas as pd
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn import metrics
from sklearn.tree import plot_tree

import matplotlib.pyplot as plt

# Load the iris dataset
iris = load_iris()
X = iris.data
y = iris.target

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=1)

# Create a Decision Tree classifier and train it
clf = DecisionTreeClassifier()
clf = clf.fit(X_train, y_train)

# Predict the response for the test dataset
y_pred = clf.predict(X_test)

# Calculate accuracy
accuracy = metrics.accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy * 100:.2f}%")

# Visualize the Decision Tree
plt.figure(figsize=(12, 8))
plot_tree(clf, feature_names=iris.feature_names, class_names=iris.target_names, filled=True)
plt.show()

# Predict for user input
def predict_user_input():
    print("Enter the values for the following features:")
    sepal_length = float(input("Sepal length: "))
    sepal_width = float(input("Sepal width: "))
    petal_length = float(input("Petal length: "))
    petal_width = float(input("Petal width: "))
    
    user_data = [[sepal_length, sepal_width, petal_length, petal_width]]
    prediction = clf.predict(user_data)
    print(f"Predicted class: {iris.target_names[prediction][0]}")

    # Visualize the user input prediction
    plt.figure(figsize=(12, 8))
    plot_tree(clf, feature_names=iris.feature_names, class_names=iris.target_names, filled=True)
    plt.scatter(sepal_length, sepal_width, color='red', label='User Input')
    plt.legend()
    plt.show()

predict_user_input()