import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

import matplotlib.pyplot as plt

# Load the iris dataset
iris = load_iris()
X = iris.data
y = iris.target

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Standardize the features
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Train the QDA model
qda = QuadraticDiscriminantAnalysis()
qda.fit(X_train, y_train)

# Make predictions
y_pred = qda.predict(X_test)

# Evaluate the model
accuracy = accuracy_score(y_test, y_pred)
print(f'Accuracy: {accuracy:.2f}')
print('Classification Report:')
print(classification_report(y_test, y_pred))
print('Confusion Matrix:')
print(confusion_matrix(y_test, y_pred))

# Visualize the data
plt.figure(figsize=(10, 6))
for i, color, label in zip([0, 1, 2], ['red', 'green', 'blue'], iris.target_names):
    plt.scatter(X_test[y_test == i, 0], X_test[y_test == i, 1], color=color, label=label)
plt.title('Iris Data - QDA Classification')
plt.xlabel(iris.feature_names[0])
plt.ylabel(iris.feature_names[1])
plt.legend()
plt.show()

# Predict for user input
user_input = np.array([[5.1, 3.5, 1.4, 0.2]])  # Example input
user_input_scaled = scaler.transform(user_input)
user_prediction = qda.predict(user_input_scaled)
print(f'User input prediction: {iris.target_names[user_prediction][0]}')

# Visualize the user input prediction
plt.figure(figsize=(10, 6))
for i, color, label in zip([0, 1, 2], ['red', 'green', 'blue'], iris.target_names):
    plt.scatter(X_test[y_test == i, 0], X_test[y_test == i, 1], color=color, label=label)
plt.scatter(user_input_scaled[0, 0], user_input_scaled[0, 1], color='black', marker='x', s=100, label='User Input')
plt.title('Iris Data - QDA Classification with User Input')
plt.xlabel(iris.feature_names[0])
plt.ylabel(iris.feature_names[1])
plt.legend()
plt.show()