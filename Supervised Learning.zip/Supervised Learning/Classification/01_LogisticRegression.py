import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn import datasets
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
import matplotlib.pyplot as plt

# Load dataset
iris = datasets.load_iris()
X = iris.data[:, :2]  # We will use only the first two features for simplicity
y = iris.target

#print iris data, description
print(iris.DESCR)
print(iris.data)
# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Train the Logistic Regression model
model = LogisticRegression()
model.fit(X_train, y_train)

# Predict the test set results
y_pred = model.predict(X_test)

# Show accuracy factors
accuracy = accuracy_score(y_test, y_pred)
conf_matrix = confusion_matrix(y_test, y_pred)
class_report = classification_report(y_test, y_pred)

print(f"Accuracy: {accuracy}")
print("Confusion Matrix:")
print(conf_matrix)
print("Classification Report:")
print(class_report)

# Visualize the data
plt.figure(figsize=(10, 6))
plt.scatter(X[:, 0], X[:, 1], c=y, cmap='viridis', edgecolor='k', s=100)
plt.title('Iris Data - Logistic Regression')
plt.xlabel('Sepal Length')
plt.ylabel('Sepal Width')

# Predict for user input
user_input = np.array([[float(input("Enter value for Sepal Length: ")), float(input("Enter value for Sepal Width: "))]])
user_prediction = model.predict(user_input)
plt.scatter(user_input[0, 0], user_input[0, 1], c='red', marker='x', s=200, label='User Input')
plt.legend()
plt.show()

print(f"Prediction for user input {user_input}: {iris.target_names[user_prediction][0]}")