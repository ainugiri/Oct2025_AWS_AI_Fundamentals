import numpy as np
import pandas as pd
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.metrics import accuracy_score
import seaborn as sns

import matplotlib.pyplot as plt

# Load the iris dataset
iris = load_iris()
X = iris.data
y = iris.target

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Standardize the features
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Apply LDA
lda = LDA(n_components=2)
X_train_lda = lda.fit_transform(X_train, y_train)
X_test_lda = lda.transform(X_test)

# Train the model
lda.fit(X_train_lda, y_train)

# Predict the test set results
y_pred = lda.predict(X_test_lda)

# Calculate accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f'Accuracy: {accuracy * 100:.2f}%')

# Visualize the data
plt.figure(figsize=(8, 6))
sns.scatterplot(x=X_train_lda[:, 0], y=X_train_lda[:, 1], hue=y_train, palette='viridis', s=100, alpha=0.7)
plt.title('LDA: Training Data')
plt.xlabel('LD1')
plt.ylabel('LD2')
plt.show()

# Predict for user input
user_input = np.array([[5.1, 3.5, 1.4, 0.2]])  # Example input
user_input_scaled = scaler.transform(user_input)
user_input_lda = lda.transform(user_input_scaled)  # Transform to LDA space
user_prediction = lda.predict(user_input_lda)
print(f'User input prediction: {iris.target_names[user_prediction][0]}')

# Visualize the user input prediction
plt.figure(figsize=(8, 6))
sns.scatterplot(x=X_train_lda[:, 0], y=X_train_lda[:, 1], hue=y_train, palette='viridis', s=100, alpha=0.7)
plt.scatter(user_input_lda[:, 0], user_input_lda[:, 1], color='red', s=200, marker='X', label='User Input')
plt.title('LDA: Training Data with User Input')
plt.xlabel('LD1')
plt.ylabel('LD2')
plt.legend()
plt.show()
# ...existing code...# ...existing code...

# Predict for user input
user_input = np.array([[5.1, 3.5, 1.4, 0.2]])  # Example input
user_input_scaled = scaler.transform(user_input)
user_input_lda = lda.transform(user_input_scaled)  # Transform to LDA space
user_prediction = lda.predict(user_input_lda)
print(f'User input prediction: {iris.target_names[user_prediction][0]}')

# Visualize the user input prediction
plt.figure(figsize=(8, 6))
sns.scatterplot(x=X_train_lda[:, 0], y=X_train_lda[:, 1], hue=y_train, palette='viridis', s=100, alpha=0.7)
plt.scatter(user_input_lda[:, 0], user_input_lda[:, 1], color='red', s=200, marker='X', label='User Input')
plt.title('LDA: Training Data with User Input')
plt.xlabel('LD1')
plt.ylabel('LD2')
plt.legend()
plt.show()
# ...existing code...