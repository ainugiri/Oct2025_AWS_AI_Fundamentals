import numpy as np
import pandas as pd
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import BernoulliNB
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
import seaborn as sns

import matplotlib.pyplot as plt

# Load Iris dataset
iris = load_iris()
X = iris.data
y = iris.target

# Binarize the data
X_binarized = np.where(X > np.mean(X, axis=0), 1, 0)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X_binarized, y, test_size=0.3, random_state=42)

# Initialize and train the Bernoulli Naive Bayes model
model = BernoulliNB()
model.fit(X_train, y_train)

# Predict the labels for the test set
y_pred = model.predict(X_test)

# Calculate accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f'Accuracy: {accuracy * 100:.2f}%')

# Show classification report
print("Classification Report:")
print(classification_report(y_test, y_pred))

# Show confusion matrix
conf_matrix = confusion_matrix(y_test, y_pred)
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', xticklabels=iris.target_names, yticklabels=iris.target_names)
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Confusion Matrix')
plt.show()

# Visualize the data
plt.figure(figsize=(10, 6))
for i in range(3):
    plt.scatter(X_binarized[y == i][:, 0], X_binarized[y == i][:, 1], label=iris.target_names[i])
plt.legend()
plt.title('Iris Data Visualization')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.show()

# Predict for user input
user_input = np.array([[5.1, 3.5, 1.4, 0.2]])  # Example input
user_input_binarized = np.where(user_input > np.mean(X, axis=0), 1, 0)
user_prediction = model.predict(user_input_binarized)
print(f'Predicted class for user input: {iris.target_names[user_prediction][0]}')