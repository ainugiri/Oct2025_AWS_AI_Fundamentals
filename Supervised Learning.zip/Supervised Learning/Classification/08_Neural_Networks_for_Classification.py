import numpy as np
import pandas as pd
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import seaborn as sns

import matplotlib.pyplot as plt

# Load the Iris dataset
iris = load_iris()
X = iris.data
y = iris.target

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Standardize the features
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Create and train the neural network model
mlp = MLPClassifier(hidden_layer_sizes=(10, 10), max_iter=1000, random_state=42)
mlp.fit(X_train, y_train)

# Predict the test set results
y_pred = mlp.predict(X_test)

# Calculate accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f'Accuracy: {accuracy * 100:.2f}%')

# Show classification report
print(classification_report(y_test, y_pred))

# Show confusion matrix
conf_matrix = confusion_matrix(y_test, y_pred)
sns.heatmap(conf_matrix, annot=True, cmap='Blues', fmt='g')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Confusion Matrix')
plt.show()

# Visualize the data
plt.figure(figsize=(10, 6))
for i in range(len(iris.target_names)):
    subset = X[y == i]
    plt.scatter(subset[:, 0], subset[:, 1], label=iris.target_names[i])
plt.xlabel(iris.feature_names[0])
plt.ylabel(iris.feature_names[1])
plt.legend()
plt.title('Iris Data Visualization')
plt.show()

# Predict for user input
user_input = np.array([[5.1, 3.5, 1.4, 0.2]])  # Example input
user_input_scaled = scaler.transform(user_input)
user_prediction = mlp.predict(user_input_scaled)
print(f'Predicted class for user input: {iris.target_names[user_prediction][0]}')

# Visualize the user input prediction
plt.figure(figsize=(10, 6))
for i in range(len(iris.target_names)):
    subset = X[y == i]
    plt.scatter(subset[:, 0], subset[:, 1], label=iris.target_names[i])
plt.scatter(user_input[0, 0], user_input[0, 1], color='red', marker='x', s=100, label='User Input')
plt.xlabel(iris.feature_names[0])
plt.ylabel(iris.feature_names[1])
plt.legend()
plt.title('Iris Data Visualization with User Input')
plt.show()