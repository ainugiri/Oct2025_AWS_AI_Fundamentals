from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes impoart MultinomialNB
from sklearn.metrics import accuracy_score, classification_report

emails = [
    "Congratulation, you have won a lottery",
    "Buy one and get one free",
    "Session start from 10th July",
    "Review the product and get 10% discount",
    "Review the document and send feedback",
    "Reminder: Session start from 10th July",
    "Free gift on purchase of $1000",
    "Free gift on purchase of $1000",
    "Free gift on purchase of $1000",
]
labels = [0,0,1,0,1,1,0,0,0]

vectorizer = CountVectorizer()
X = vectorizer.fit_transform(emails)
y = labels

nb_model = MultinomialNB()
nb_model.fit(X, y)

y_pred = nb_model.predict(X)

accuracy = accuracy_score(y, y_pred)
report = classification_report(y, y_pred)
features = vectorizer.get_feature_names_out()
features_probs = nb_model.feature_log_prob_

sample_mail_head = ["Congratulation, you have won a lottery",
                    "Review the document and send feedback",
                    "Free gift on purchase of $1000"]

print("Result")
for mail, pred in zip(sample_mail_head, nb_model.predict(vectorizer.transform(sample_mail_head))):
    label = 'Spam' if pred == 0 else 'Not Spam'
    print(f"{mail} => {'Spam' if pred == 0 else 'Not Spam'}")