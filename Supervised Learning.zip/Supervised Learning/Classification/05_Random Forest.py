import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

import matplotlib.pyplot as plt

# Load the Iris dataset

iris = load_iris()
X = iris.data
y = iris.target

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Create a Random Forest Classifier
clf = RandomForestClassifier(n_estimators=100, random_state=42)

# Train the model
clf.fit(X_train, y_train)

# Make predictions
y_pred = clf.predict(X_test)

# Calculate accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f'Accuracy: {accuracy:.2f}')

# Show classification report
print('Classification Report:')
print(classification_report(y_test, y_pred))

# Show confusion matrix
conf_matrix = confusion_matrix(y_test, y_pred)
sns.heatmap(conf_matrix, annot=True, cmap='Blues', fmt='g')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Confusion Matrix')
plt.show()

# Visualize the data
sns.pairplot(pd.DataFrame(X, columns=iris.feature_names).assign(species=pd.Categorical.from_codes(y, iris.target_names)), hue='species')
plt.show()

# Predict for user input
def predict_iris(sepal_length, sepal_width, petal_length, petal_width):
    user_input = np.array([[sepal_length, sepal_width, petal_length, petal_width]])
    prediction = clf.predict(user_input)
    return iris.target_names[prediction][0]

# Example user input
sepal_length = float(input("Enter sepal length: "))
sepal_width = float(input("Enter sepal width: "))
petal_length = float(input("Enter petal length: "))
petal_width = float(input("Enter petal width: "))

predicted_class = predict_iris(sepal_length, sepal_width, petal_length, petal_width)
print(f'The predicted class for the given input is: {predicted_class}')